echo "Benchmark with in=../../lib/common"
./benchmark in=../../../lib/common
